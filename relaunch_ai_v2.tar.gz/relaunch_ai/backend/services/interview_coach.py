"""
Interview Coach Service
Generates confident answers for explaining career breaks and other common questions.
"""

import json
import logging
from backend.config import get_ai_client, settings
from backend.models import InterviewPrep, InterviewAnswer, UserProfile

logger = logging.getLogger(__name__)


SYSTEM_PROMPT = """You are an expert interview coach specializing in helping professionals confidently discuss career breaks.

Your task is to create:
1. Confident, concise answers about the career break
2. Responses that reframe the break as valuable experience
3. Strategies for handling potential objections
4. Tips for projecting confidence and readiness

Guidelines:
- Answers should be 60-90 seconds when spoken
- Use positive, forward-looking language
- Avoid over-explaining or apologizing
- Emphasize skills gained during the break
- Show enthusiasm and readiness to contribute
- Address concerns without being defensive
- Include specific examples where possible

Output must be valid JSON matching the specified schema."""


def generate_interview_answers(profile: UserProfile) -> InterviewPrep:
    """
    Generate interview answers and coaching for returning professionals.
    
    Args:
        profile: UserProfile with career details
        
    Returns:
        InterviewPrep with Q&A and tips
    """
    client = get_ai_client()
    
    break_context = {
        "maternity": "maternity leave and early childcare responsibilities",
        "childcare": "dedicated time raising and caring for children",
        "eldercare": "caring for elderly family members",
        "health": "personal health and wellness period",
        "relocation": "family relocation and settling period",
        "education": "pursuing further education and certifications",
        "personal": "personal growth and reflection period",
        "other": "personal circumstances"
    }
    
    break_description = break_context.get(profile.break_reason.value, "personal circumstances")
    
    user_prompt = f"""Create interview coaching content for this professional:

NAME: {profile.name}
PREVIOUS ROLE: {profile.previous_role}
YEARS OF EXPERIENCE: {profile.years_experience}
CAREER BREAK: {profile.break_duration_months} months for {break_description}
SKILLS: {', '.join(profile.skills_known)}
TARGET ROLE: {profile.target_role}

Generate confident answers for these scenarios:

1. EXPLAINING THE CAREER BREAK
   - Create a concise, confident answer (60-90 seconds)
   - Include 3 delivery tips

2. ADDRESSING SKILL REFRESH NEEDS
   - Answer about staying current and ready
   - Include 3 tips for demonstrating currency

3. MOTIVATION FOR RETURNING
   - Answer about why now and commitment level
   - Include 3 tips for showing dedication

4. HANDLING POTENTIAL OBJECTIONS
   - Answer for "Are you ready to commit?" type concerns
   - Include 3 tips for addressing skepticism

5. GENERAL INTERVIEW TIPS (5-7 tips)

Respond with JSON in this exact format:
{{
    "break_explanation": {{
        "question": "Can you tell us about the gap in your resume?",
        "answer": "Confident 60-90 second response...",
        "tips": ["Tip 1", "Tip 2", "Tip 3"]
    }},
    "skill_refresh": {{
        "question": "How have you kept your skills current?",
        "answer": "Response about staying updated...",
        "tips": ["Tip 1", "Tip 2", "Tip 3"]
    }},
    "motivation_return": {{
        "question": "Why do you want to return to work now?",
        "answer": "Response about motivation...",
        "tips": ["Tip 1", "Tip 2", "Tip 3"]
    }},
    "handling_objections": {{
        "question": "How do we know you're ready for this commitment?",
        "answer": "Response addressing concerns...",
        "tips": ["Tip 1", "Tip 2", "Tip 3"]
    }},
    "general_tips": ["Tip 1", "Tip 2", "Tip 3", "Tip 4", "Tip 5"]
}}"""

    try:
        logger.info(f"Generating interview answers for user: {profile.name}")
        
        response = client.chat.completions.create(
            model=settings.sambanova_model,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_prompt}
            ],
            temperature=0.7,
            max_tokens=2500,
            response_format={"type": "json_object"}
        )
        
        result = json.loads(response.choices[0].message.content)
        
        return InterviewPrep(
            break_explanation=InterviewAnswer(**result["break_explanation"]),
            skill_refresh=InterviewAnswer(**result["skill_refresh"]),
            motivation_return=InterviewAnswer(**result["motivation_return"]),
            handling_objections=InterviewAnswer(**result["handling_objections"]),
            general_tips=result.get("general_tips", [])
        )
        
    except Exception as e:
        logger.error(f"Error in interview coaching: {str(e)}")
        raise Exception(f"Failed to generate interview coaching: {str(e)}")
