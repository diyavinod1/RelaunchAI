# 🚀 ReLaunchAI - Career Reintegration Assistant

An AI-powered assistant designed to help women confidently return to the workforce after career breaks.

## Features

- **📊 Skill Gap Analysis** - Identify transferable skills and development priorities
- **📝 Resume Summary Generator** - Create compelling professional summaries
- **🎯 Interview Coach** - Confident answers for explaining career breaks
- **📅 30-Day Roadmap** - Structured daily action plan for your comeback
- **🏢 Returnship Programs** - Discover relevant return-to-work programs

## Tech Stack

**Backend:**
- Python 3.9+
- FastAPI
- OpenAI GPT-4
- Pydantic

**Frontend:**
- Streamlit

## Project Structure

```
relaunch_ai/
│
├── backend/
│   ├── __init__.py
│   ├── main.py              # FastAPI application
│   ├── agent.py             # AI Agent orchestrator
│   ├── models.py            # Pydantic models
│   ├── config.py            # Configuration settings
│   └── services/
│       ├── __init__.py
│       ├── skill_gap.py     # Skill gap analysis
│       ├── resume_generator.py
│       ├── interview_coach.py
│       ├── roadmap_planner.py
│       └── returnship_finder.py
│
├── frontend/
│   └── app.py               # Streamlit UI
│
├── .env                     # Environment variables
├── requirements.txt
└── README.md
```

## Setup Instructions

### 1. Clone and Navigate

```bash
cd relaunch_ai
```

### 2. Create Virtual Environment

```bash
# Create virtual environment
python -m venv venv

# Activate (Windows)
venv\Scripts\activate

# Activate (macOS/Linux)
source venv/bin/activate
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

### 4. Configure API Key

Edit the `.env` file and add your OpenAI API key:

```
OPENAI_API_KEY=sk-your-actual-api-key-here
```

Get your API key from: https://platform.openai.com/api-keys

## Running the Application

### Start the Backend (Terminal 1)

```bash
# From the project root directory
python -m backend.main
```

The backend will start on `http://localhost:8000`

**API Documentation:** Visit `http://localhost:8000/docs` for interactive API documentation.

### Start the Frontend (Terminal 2)

Open a new terminal and run:

```bash
# From the project root directory
streamlit run frontend/app.py
```

The frontend will open in your browser at `http://localhost:8501`

## Usage

1. Open the Streamlit app in your browser
2. Fill in your profile details:
   - Name and education
   - Previous role and experience
   - Career break details
   - Current skills and target role
3. Click "Generate My Comeback Plan"
4. Review your personalized recommendations across all tabs

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | Health check |
| `/health` | GET | API health status |
| `/api/analyze` | POST | Complete analysis pipeline |
| `/api/skill-gap` | POST | Skill gap analysis only |
| `/api/resume` | POST | Resume summary only |
| `/api/interview` | POST | Interview prep only |
| `/api/roadmap` | POST | 30-day roadmap only |
| `/api/returnships` | POST | Returnship programs only |

## Example API Request

```bash
curl -X POST "http://localhost:8000/api/analyze" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Jane Doe",
    "education": "Bachelor of Science in Computer Science",
    "previous_role": "Software Engineer",
    "years_experience": 5,
    "break_duration_months": 24,
    "break_reason": "childcare",
    "skills_known": ["Python", "Java", "SQL", "Agile"],
    "target_role": "Senior Software Engineer",
    "industry": "Technology",
    "location": "San Francisco, CA"
  }'
```

## Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `OPENAI_API_KEY` | Your OpenAI API key | Required |
| `OPENAI_MODEL` | OpenAI model to use | gpt-4o-mini |
| `APP_NAME` | Application name | ReLaunchAI |
| `DEBUG` | Debug mode | false |

## Troubleshooting

### Backend won't start
- Check if port 8000 is already in use
- Ensure all dependencies are installed: `pip install -r requirements.txt`
- Verify Python version is 3.9 or higher

### Frontend can't connect to backend
- Make sure backend is running on port 8000
- Check firewall settings
- Verify `API_BASE_URL` in `frontend/app.py` matches your backend URL

### OpenAI API errors
- Verify your API key is correctly set in `.env`
- Check your OpenAI account has available credits
- Ensure the model specified is available on your account

## License

MIT License - Feel free to use and modify for your needs.

## Support

For issues or questions, please open an issue in the project repository.

---

**Built with ❤️ for empowering career returns**
