"""
Skill Gap Analysis Service
Analyzes user's current skills against target role requirements.
"""

import json
import logging
from typing import List
from backend.config import get_openai_client, settings
from backend.models import SkillGapAnalysis, SkillGap, UserProfile

logger = logging.getLogger(__name__)


SYSTEM_PROMPT = """You are an expert career counselor and skills analyst specializing in helping professionals return to the workforce after career breaks.

Your task is to analyze a user's current skills against their target role and identify:
1. Transferable skills they already possess
2. Skill gaps they need to address
3. Priority order for upskilling
4. Learning resources and time estimates

Guidelines:
- Be encouraging and supportive in tone
- Focus on realistic, achievable skill development
- Consider industry trends and market demands
- Account for skills that may need refreshing after a career break
- Provide specific, actionable recommendations
- Avoid gender bias or assumptions about capabilities

Output must be valid JSON matching the specified schema."""


def analyze_skill_gaps(profile: UserProfile) -> SkillGapAnalysis:
    """
    Analyze skill gaps between user's profile and target role.
    
    Args:
        profile: UserProfile with career details
        
    Returns:
        SkillGapAnalysis with detailed recommendations
    """
    client = get_openai_client()
    
    user_prompt = f"""Analyze the skill gaps for this professional returning to work:

NAME: {profile.name}
PREVIOUS ROLE: {profile.previous_role}
YEARS OF EXPERIENCE: {profile.years_experience}
CAREER BREAK: {profile.break_duration_months} months
BREAK REASON: {profile.break_reason.value}
EDUCATION: {profile.education}
CURRENT SKILLS: {', '.join(profile.skills_known)}
TARGET ROLE: {profile.target_role}
INDUSTRY: {profile.industry or 'Not specified'}

Provide a comprehensive skill gap analysis including:
1. Transferable skills from their background
2. Specific skill gaps with importance levels
3. Learning resources for each gap
4. Market trends relevant to their target role

Respond with JSON in this exact format:
{{
    "transferable_skills": ["skill1", "skill2", ...],
    "skill_gaps": [
        {{
            "skill_name": "Skill Name",
            "importance": "High/Medium/Low",
            "gap_level": "Critical/Moderate/Minor",
            "learning_resources": ["resource1", "resource2"],
            "estimated_time_weeks": 4
        }}
    ],
    "upskilling_priority": ["skill1", "skill2", ...],
    "market_trends_note": "Brief note on industry trends"
}}"""

    try:
        logger.info(f"Analyzing skill gaps for user: {profile.name}")
        
        response = client.chat.completions.create(
            model=settings.openai_model,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_prompt}
            ],
            temperature=0.7,
            max_tokens=2000,
            response_format={"type": "json_object"}
        )
        
        result = json.loads(response.choices[0].message.content)
        
        # Validate and construct SkillGap objects
        skill_gaps = [
            SkillGap(
                skill_name=sg["skill_name"],
                importance=sg["importance"],
                gap_level=sg["gap_level"],
                learning_resources=sg["learning_resources"],
                estimated_time_weeks=sg["estimated_time_weeks"]
            )
            for sg in result.get("skill_gaps", [])
        ]
        
        return SkillGapAnalysis(
            transferable_skills=result.get("transferable_skills", []),
            skill_gaps=skill_gaps,
            upskilling_priority=result.get("upskilling_priority", []),
            market_trends_note=result.get("market_trends_note", "")
        )
        
    except Exception as e:
        logger.error(f"Error in skill gap analysis: {str(e)}")
        raise Exception(f"Failed to analyze skill gaps: {str(e)}")
