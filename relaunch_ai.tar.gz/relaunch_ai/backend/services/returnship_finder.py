"""
Returnship Program Finder Service
Suggests relevant returnship programs and provides guidance.
"""

import json
import logging
from backend.config import get_openai_client, settings
from backend.models import ReturnshipSuggestions, ReturnshipProgram, UserProfile

logger = logging.getLogger(__name__)


SYSTEM_PROMPT = """You are an expert in returnship programs and career reintegration initiatives.

Your task is to recommend relevant returnship programs and provide guidance on:
1. Specific returnship programs by major companies
2. Eligibility requirements and application tips
3. Alternative pathways for career reentry
4. Networking strategies for returnship opportunities

Guidelines:
- Focus on legitimate, well-established programs
- Include programs from diverse industries
- Provide realistic eligibility criteria
- Include both formal returnships and alternative pathways
- Consider geographic relevance
- Offer networking and application advice
- Be encouraging about the value of these programs

Output must be valid JSON matching the specified schema."""


def find_returnship_programs(profile: UserProfile) -> ReturnshipSuggestions:
    """
    Find relevant returnship programs for returning professionals.
    
    Args:
        profile: UserProfile with career details
        
    Returns:
        ReturnshipSuggestions with program recommendations
    """
    client = get_openai_client()
    
    user_prompt = f"""Recommend returnship programs for this professional:

NAME: {profile.name}
PREVIOUS ROLE: {profile.previous_role}
YEARS OF EXPERIENCE: {profile.years_experience}
TARGET ROLE: {profile.target_role}
INDUSTRY: {profile.industry or 'Not specified'}
LOCATION: {profile.location or 'Any location'}
SKILLS: {', '.join(profile.skills_known)}

Provide:

1. RECOMMENDED PROGRAMS (5-7 programs):
   Include well-known returnship programs such as:
   - Path Forward (multiple companies)
   - iRelaunch programs
   - Company-specific programs (JP Morgan, Goldman Sachs, Morgan Stanley, Deloitte, etc.)
   - Tech company returnships (Amazon, Google, Microsoft)
   - Industry-specific programs

2. GENERAL ADVICE: Paragraph on approaching returnships

3. NETWORKING TIPS: 5-7 specific tips for finding opportunities

Respond with JSON in this exact format:
{{
    "recommended_programs": [
        {{
            "program_name": "Program Name",
            "company": "Company Name",
            "location": "Location(s)",
            "duration": "e.g., 16 weeks",
            "description": "Brief description",
            "eligibility": "Who can apply",
            "application_link": "URL or 'Search: program name'",
            "deadline": "Application deadline info or 'Rolling'"
        }}
    ],
    "general_advice": "Paragraph of advice...",
    "networking_tips": ["Tip 1", "Tip 2", "Tip 3", "Tip 4", "Tip 5"]
}}"""

    try:
        logger.info(f"Finding returnship programs for user: {profile.name}")
        
        response = client.chat.completions.create(
            model=settings.openai_model,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_prompt}
            ],
            temperature=0.7,
            max_tokens=2500,
            response_format={"type": "json_object"}
        )
        
        result = json.loads(response.choices[0].message.content)
        
        # Construct ReturnshipProgram objects
        programs = [
            ReturnshipProgram(
                program_name=rp["program_name"],
                company=rp["company"],
                location=rp["location"],
                duration=rp["duration"],
                description=rp["description"],
                eligibility=rp["eligibility"],
                application_link=rp.get("application_link"),
                deadline=rp.get("deadline")
            )
            for rp in result.get("recommended_programs", [])
        ]
        
        return ReturnshipSuggestions(
            recommended_programs=programs,
            general_advice=result.get("general_advice", ""),
            networking_tips=result.get("networking_tips", [])
        )
        
    except Exception as e:
        logger.error(f"Error in returnship finder: {str(e)}")
        raise Exception(f"Failed to find returnship programs: {str(e)}")
