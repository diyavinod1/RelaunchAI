"""
Configuration module for ReLaunchAI backend.
Handles environment variables and application settings.
"""

import os
from dotenv import load_dotenv
from pydantic_settings import BaseSettings
from pydantic import Field

# Load environment variables from .env file
load_dotenv()


class Settings(BaseSettings):
    """Application settings with environment variable support."""
    
    # OpenAI Configuration
    openai_api_key: str = Field(default="", alias="OPENAI_API_KEY")
    openai_model: str = Field(default="gpt-4o-mini", alias="OPENAI_MODEL")
    
    # Application Settings
    app_name: str = Field(default="ReLaunchAI", alias="APP_NAME")
    app_version: str = Field(default="1.0.0", alias="APP_VERSION")
    debug: bool = Field(default=False, alias="DEBUG")
    
    # API Settings
    api_host: str = "0.0.0.0"
    api_port: int = 8000
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        populate_by_name = True


# Global settings instance
settings = Settings()


def get_openai_client():
    """Initialize and return OpenAI client."""
    from openai import OpenAI
    
    if not settings.openai_api_key or settings.openai_api_key == "your_openai_api_key_here":
        raise ValueError("OpenAI API key not configured. Please set OPENAI_API_KEY in .env file.")
    
    return OpenAI(api_key=settings.openai_api_key)
