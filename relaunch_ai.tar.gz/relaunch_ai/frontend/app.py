"""
ReLaunchAI Frontend - Streamlit Application
User interface for the Career Reintegration Assistant.
"""

import streamlit as st
import requests
import json
from datetime import datetime

# Page configuration
st.set_page_config(
    page_title="ReLaunchAI - Career Reintegration Assistant",
    page_icon="🚀",
    layout="wide",
    initial_sidebar_state="expanded"
)

# API Configuration
API_BASE_URL = "http://localhost:8000"

# Custom CSS for styling
st.markdown("""
<style>
    .main-header {
        font-size: 3rem;
        font-weight: bold;
        color: #1E3A8A;
        text-align: center;
        margin-bottom: 0.5rem;
    }
    .sub-header {
        font-size: 1.2rem;
        color: #6B7280;
        text-align: center;
        margin-bottom: 2rem;
    }
    .section-header {
        font-size: 1.5rem;
        font-weight: bold;
        color: #1E3A8A;
        margin-top: 1.5rem;
        margin-bottom: 1rem;
        border-bottom: 2px solid #E5E7EB;
        padding-bottom: 0.5rem;
    }
    .info-box {
        background-color: #EFF6FF;
        border-left: 4px solid #3B82F6;
        padding: 1rem;
        margin: 1rem 0;
        border-radius: 0.25rem;
    }
    .success-box {
        background-color: #ECFDF5;
        border-left: 4px solid #10B981;
        padding: 1rem;
        margin: 1rem 0;
        border-radius: 0.25rem;
    }
    .warning-box {
        background-color: #FFFBEB;
        border-left: 4px solid #F59E0B;
        padding: 1rem;
        margin: 1rem 0;
        border-radius: 0.25rem;
    }
    .skill-tag {
        display: inline-block;
        background-color: #DBEAFE;
        color: #1E40AF;
        padding: 0.25rem 0.75rem;
        margin: 0.25rem;
        border-radius: 9999px;
        font-size: 0.875rem;
    }
    .gap-critical {
        background-color: #FEE2E2;
        color: #991B1B;
        padding: 0.5rem;
        border-radius: 0.25rem;
        margin: 0.25rem 0;
    }
    .gap-moderate {
        background-color: #FFFBEB;
        color: #92400E;
        padding: 0.5rem;
        border-radius: 0.25rem;
        margin: 0.25rem 0;
    }
    .gap-minor {
        background-color: #ECFDF5;
        color: #065F46;
        padding: 0.5rem;
        border-radius: 0.25rem;
        margin: 0.25rem 0;
    }
    .stButton>button {
        background-color: #1E3A8A;
        color: white;
        font-weight: bold;
        padding: 0.75rem 2rem;
        border-radius: 0.5rem;
        width: 100%;
    }
    .stButton>button:hover {
        background-color: #1E40AF;
    }
</style>
""", unsafe_allow_html=True)


def check_api_health():
    """Check if backend API is running."""
    try:
        response = requests.get(f"{API_BASE_URL}/health", timeout=5)
        return response.status_code == 200
    except:
        return False


def render_header():
    """Render application header."""
    st.markdown('<div class="main-header">🚀 ReLaunchAI</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="sub-header">Your AI-Powered Career Reintegration Assistant</div>',
        unsafe_allow_html=True
    )
    st.markdown("---")


def render_sidebar():
    """Render sidebar with information."""
    with st.sidebar:
        st.header("About ReLaunchAI")
        st.markdown("""
        **ReLaunchAI** helps women returning to work after career breaks by:
        
        ✨ **Skill Gap Analysis**  
        📝 **Resume Rewriting**  
        🎯 **Interview Coaching**  
        📅 **30-Day Roadmap**  
        🏢 **Returnship Programs**
        
        ---
        
        **How it works:**
        1. Fill in your profile details
        2. Click "Generate My Comeback Plan"
        3. Review personalized recommendations
        4. Take action with confidence!
        
        ---
        
        *Built with ❤️ for your successful return to work*
        """)


def render_input_form():
    """Render user input form."""
    st.markdown('<div class="section-header">👤 Your Profile</div>', unsafe_allow_html=True)
    
    with st.container():
        col1, col2 = st.columns(2)
        
        with col1:
            name = st.text_input("Full Name *", placeholder="e.g., Sarah Johnson")
            education = st.text_input("Education *", placeholder="e.g., MBA, Computer Science")
            previous_role = st.text_input("Previous Job Role *", placeholder="e.g., Marketing Manager")
            years_experience = st.number_input(
                "Years of Experience *", 
                min_value=0, 
                max_value=50, 
                value=5
            )
        
        with col2:
            break_duration = st.number_input(
                "Career Break Duration (months) *",
                min_value=1,
                max_value=240,
                value=24
            )
            
            break_reason = st.selectbox(
                "Reason for Career Break *",
                options=[
                    ("maternity", "Maternity Leave"),
                    ("childcare", "Childcare / Family Care"),
                    ("eldercare", "Eldercare"),
                    ("health", "Health / Personal Wellness"),
                    ("relocation", "Relocation"),
                    ("education", "Further Education"),
                    ("personal", "Personal Growth"),
                    ("other", "Other")
                ],
                format_func=lambda x: x[1]
            )
            
            break_details = st.text_area(
                "Additional Details (optional)",
                placeholder="Any context about your break...",
                max_chars=500
            )
        
        st.markdown("---")
        
        col3, col4 = st.columns(2)
        
        with col3:
            skills_input = st.text_area(
                "Your Skills (comma-separated) *",
                placeholder="e.g., Project Management, Data Analysis, Python, Team Leadership",
                height=100
            )
        
        with col4:
            target_role = st.text_input("Target Role *", placeholder="e.g., Product Manager")
            industry = st.text_input("Target Industry (optional)", placeholder="e.g., Technology")
            location = st.text_input("Your Location (optional)", placeholder="e.g., New York, NY")
    
    # Parse skills
    skills = [s.strip() for s in skills_input.split(",") if s.strip()] if skills_input else []
    
    return {
        "name": name,
        "education": education,
        "previous_role": previous_role,
        "years_experience": years_experience,
        "break_duration_months": break_duration,
        "break_reason": break_reason[0],
        "break_reason_details": break_details if break_details else None,
        "skills_known": skills,
        "target_role": target_role,
        "industry": industry if industry else None,
        "location": location if location else None
    }


def validate_inputs(data):
    """Validate form inputs."""
    required_fields = ["name", "education", "previous_role", "target_role"]
    errors = []
    
    for field in required_fields:
        if not data.get(field):
            errors.append(f"{field.replace('_', ' ').title()} is required")
    
    if not data.get("skills_known"):
        errors.append("At least one skill is required")
    
    return errors


def call_api(endpoint, data):
    """Make API call to backend."""
    try:
        response = requests.post(
            f"{API_BASE_URL}{endpoint}",
            json=data,
            timeout=120
        )
        response.raise_for_status()
        return response.json()
    except requests.exceptions.ConnectionError:
        st.error("❌ Cannot connect to backend. Please ensure the backend server is running.")
        return None
    except requests.exceptions.Timeout:
        st.error("❌ Request timed out. Please try again.")
        return None
    except requests.exceptions.HTTPError as e:
        st.error(f"❌ API Error: {e.response.text}")
        return None
    except Exception as e:
        st.error(f"❌ Error: {str(e)}")
        return None


def render_skill_gap_analysis(data):
    """Render skill gap analysis section."""
    st.markdown('<div class="section-header">📊 Skill Gap Analysis</div>', unsafe_allow_html=True)
    
    # Transferable skills
    st.subheader("✅ Your Transferable Skills")
    skills_html = ""
    for skill in data.get("transferable_skills", []):
        skills_html += f'<span class="skill-tag">{skill}</span>'
    st.markdown(skills_html, unsafe_allow_html=True)
    
    # Skill gaps
    st.subheader("📈 Skills to Develop")
    for gap in data.get("skill_gaps", []):
        gap_class = f"gap-{gap['gap_level'].lower()}"
        importance_color = "🔴" if gap['importance'] == "High" else "🟡" if gap['importance'] == "Medium" else "🟢"
        
        with st.expander(f"{importance_color} {gap['skill_name']} ({gap['importance']} Priority)"):
            st.markdown(f"**Gap Level:** {gap['gap_level']}")
            st.markdown(f"**Estimated Time:** {gap['estimated_time_weeks']} weeks")
            st.markdown("**Learning Resources:**")
            for resource in gap['learning_resources']:
                st.markdown(f"- {resource}")
    
    # Upskilling priority
    st.subheader("🎯 Upskilling Priority Order")
    for i, skill in enumerate(data.get("upskilling_priority", []), 1):
        st.markdown(f"{i}. {skill}")
    
    # Market trends
    st.info(f"📢 **Market Insight:** {data.get('market_trends_note', '')}")


def render_resume_summary(data):
    """Render resume summary section."""
    st.markdown('<div class="section-header">📝 Professional Summary</div>', unsafe_allow_html=True)
    
    # Suggested headline
    st.markdown('<div class="success-box">', unsafe_allow_html=True)
    st.markdown(f"**💡 Suggested LinkedIn Headline:**\n\n*{data.get('suggested_headline', '')}*")
    st.markdown('</div>', unsafe_allow_html=True)
    
    # Professional summary
    st.subheader("📝 Resume Summary")
    st.markdown(data.get('professional_summary', ''))
    
    # Key strengths
    st.subheader("💪 Key Strengths to Highlight")
    for strength in data.get('key_strengths', []):
        st.markdown(f"✓ {strength}")
    
    # Career break positioning
    st.subheader("🔄 Positioning Your Career Break")
    st.markdown('<div class="info-box">', unsafe_allow_html=True)
    st.markdown(data.get('career_break_positioning', ''))
    st.markdown('</div>', unsafe_allow_html=True)


def render_interview_prep(data):
    """Render interview preparation section."""
    st.markdown('<div class="section-header">🎯 Interview Preparation</div>', unsafe_allow_html=True)
    
    # Break explanation
    with st.expander("💬 Explaining Your Career Break"):
        qa = data.get('break_explanation', {})
        st.markdown(f"**Q: {qa.get('question', '')}**")
        st.markdown(f"**A:** {qa.get('answer', '')}")
        st.markdown("**Tips:**")
        for tip in qa.get('tips', []):
            st.markdown(f"• {tip}")
    
    # Skill refresh
    with st.expander("💬 Addressing Skill Currency"):
        qa = data.get('skill_refresh', {})
        st.markdown(f"**Q: {qa.get('question', '')}**")
        st.markdown(f"**A:** {qa.get('answer', '')}")
        st.markdown("**Tips:**")
        for tip in qa.get('tips', []):
            st.markdown(f"• {tip}")
    
    # Motivation
    with st.expander("💬 Your Motivation to Return"):
        qa = data.get('motivation_return', {})
        st.markdown(f"**Q: {qa.get('question', '')}**")
        st.markdown(f"**A:** {qa.get('answer', '')}")
        st.markdown("**Tips:**")
        for tip in qa.get('tips', []):
            st.markdown(f"• {tip}")
    
    # Handling objections
    with st.expander("💬 Handling Concerns"):
        qa = data.get('handling_objections', {})
        st.markdown(f"**Q: {qa.get('question', '')}**")
        st.markdown(f"**A:** {qa.get('answer', '')}")
        st.markdown("**Tips:**")
        for tip in qa.get('tips', []):
            st.markdown(f"• {tip}")
    
    # General tips
    st.subheader("📌 General Interview Tips")
    for tip in data.get('general_tips', []):
        st.markdown(f"✓ {tip}")


def render_roadmap(data):
    """Render 30-day roadmap section."""
    st.markdown('<div class="section-header">📅 30-Day Comeback Roadmap</div>', unsafe_allow_html=True)
    
    # Overview
    st.markdown('<div class="info-box">', unsafe_allow_html=True)
    st.markdown(data.get('overview', ''))
    st.markdown('</div>', unsafe_allow_html=True)
    
    # Weekly focus
    st.subheader("🗓️ Weekly Focus Areas")
    for week in data.get('weekly_focus', []):
        with st.expander(f"Week {week['week']}: {week['theme']}"):
            st.markdown("**Objectives:**")
            for obj in week['objectives']:
                st.markdown(f"• {obj}")
    
    # Daily tasks
    st.subheader("📋 Daily Action Plan")
    
    # Group by week for better organization
    weeks = {}
    for task in data.get('daily_tasks', []):
        week_num = (task['day'] - 1) // 7 + 1
        if week_num not in weeks:
            weeks[week_num] = []
        weeks[week_num].append(task)
    
    for week_num, tasks in weeks.items():
        with st.expander(f"Week {week_num} Daily Tasks"):
            for task in tasks:
                col1, col2, col3 = st.columns([1, 3, 1])
                with col1:
                    st.markdown(f"**Day {task['day']}**")
                with col2:
                    st.markdown(f"{task['task']}")
                    st.caption(f"Category: {task['category']}")
                with col3:
                    st.markdown(f"⏱️ {task['estimated_hours']}h")
                st.markdown("---")
    
    # Milestones
    st.subheader("🏆 Key Milestones")
    for milestone in data.get('milestones', []):
        st.markdown(f"✓ {milestone}")


def render_returnships(data):
    """Render returnship programs section."""
    st.markdown('<div class="section-header">🏢 Returnship Programs</div>', unsafe_allow_html=True)
    
    # Recommended programs
    st.subheader("🎯 Recommended Programs")
    for program in data.get('recommended_programs', []):
        with st.expander(f"{program['program_name']} - {program['company']}"):
            col1, col2 = st.columns(2)
            with col1:
                st.markdown(f"**Location:** {program['location']}")
                st.markdown(f"**Duration:** {program['duration']}")
            with col2:
                st.markdown(f"**Eligibility:** {program['eligibility']}")
                if program.get('deadline'):
                    st.markdown(f"**Deadline:** {program['deadline']}")
            st.markdown(f"**Description:** {program['description']}")
            if program.get('application_link'):
                st.markdown(f"**Apply:** {program['application_link']}")
    
    # General advice
    st.subheader("💡 General Advice")
    st.markdown(data.get('general_advice', ''))
    
    # Networking tips
    st.subheader("🤝 Networking Tips")
    for tip in data.get('networking_tips', []):
        st.markdown(f"• {tip}")


def main():
    """Main application function."""
    render_header()
    render_sidebar()
    
    # Check API health
    if not check_api_health():
        st.warning("⚠️ Backend server is not running. Please start it first with: `python -m backend.main`")
    
    # Input form
    form_data = render_input_form()
    
    # Generate button
    st.markdown("---")
    if st.button("🚀 Generate My Comeback Plan", type="primary"):
        # Validate inputs
        errors = validate_inputs(form_data)
        if errors:
            for error in errors:
                st.error(f"❌ {error}")
            return
        
        # Call API
        with st.spinner("🤖 AI is analyzing your profile... This may take a minute."):
            result = call_api("/api/analyze", form_data)
        
        if result:
            st.success(f"✅ Welcome back, {result['user_name']}! Your personalized comeback plan is ready!")
            
            # Display results in tabs
            tab1, tab2, tab3, tab4, tab5 = st.tabs([
                "📊 Skills", "📝 Resume", "🎯 Interview", "📅 Roadmap", "🏢 Returnships"
            ])
            
            with tab1:
                render_skill_gap_analysis(result['skill_gap_analysis'])
            
            with tab2:
                render_resume_summary(result['resume_summary'])
            
            with tab3:
                render_interview_prep(result['interview_prep'])
            
            with tab4:
                render_roadmap(result['comeback_roadmap'])
            
            with tab5:
                render_returnships(result['returnship_suggestions'])
            
            # Footer
            st.markdown("---")
            st.caption(f"Generated on {datetime.fromisoformat(result['generated_at']).strftime('%B %d, %Y at %I:%M %p')}")


if __name__ == "__main__":
    main()
